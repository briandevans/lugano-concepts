Lugano protocol pack
====================

This zip is a standalone handoff of the Lugano private-inference project.

1. Read LUGANO_SUMMARY.md  (or open LUGANO_SUMMARY.html in a browser)
   Full explanation of research, product, privacy, tokenomics, earnings, and the site.

2. Optional deeper docs
   docs/PROJECT_VETTING.md   competitive research
   docs/TOKENOMICS.md        economic spec

3. Open the website
   macOS / Linux:
     chmod +x open-site.sh && ./open-site.sh
   Windows / anywhere with Python 3:
     python3 serve.py
   Then open http://127.0.0.1:4173

   Routes: /  /privacy  /earn  /tokenomics  /docs

This is a protocol design / research preview. Not a live network. Not a token offering.
PR: https://github.com/briandevans/lugano-concepts/pull/12
