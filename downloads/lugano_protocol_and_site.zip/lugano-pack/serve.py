#!/usr/bin/env python3
"""Serve the built Lugano site with SPA fallback."""

from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent / "site"
PORT = 4173


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def do_GET(self):
        path = ROOT / self.path.lstrip("/").split("?", 1)[0]
        if self.path in ("/", "") or path.exists():
            return super().do_GET()
        self.path = "/index.html"
        return super().do_GET()


if __name__ == "__main__":
    if not ROOT.exists():
        sys.exit(f"Missing site/ folder next to {__file__}")
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    print(f"Lugano site  →  http://127.0.0.1:{PORT}/")
    print("Routes: /  /privacy  /earn  /tokenomics  /docs")
    print("Ctrl+C to stop")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
